const BASE_URL = "http://localhost:8080/api";
// Load employees
function loadEmployees() {
  $.get(`${BASE_URL}/employees`, function (data) {
    $("#employeeTable").empty();
    data.forEach(emp => {
      $("#employeeTable").append(`
        <tr>
          <td>${emp.id}</td>
          <td>${emp.name}</td>
          <td>${emp.email}</td>
          <td>${emp.phone}</td>
          <td>${emp.designation}</td>
          <td>
            <button class="btn btn-sm btn-warning" onclick="editEmployee(${emp.id})">Edit</button>
            <button class="btn btn-sm btn-danger" onclick="deleteEmployee(${emp.id})">Delete</button>
          </td>
        </tr>
      `);
    });
  });
}

// Save or Update employee
function saveEmployee() {
  const emp = {
    id: $("#employeeId").val() || null,
    name: $("#name").val(),
    email: $("#email").val(),
    phone: $("#phone").val(),
    address: $("#address").val(),
    designation: $("#designation").val(),
    organizationId: $("#organizationId").val()
  };

  const url = emp.id ? `${BASE_URL}/employees/${emp.id}` : `${BASE_URL}/employees`;
  const method = emp.id ? "PUT" : "POST";

  $.ajax({
    url: url,
    type: method,
    contentType: "application/json",
    data: JSON.stringify(emp),
    success: function () {
      loadEmployees();
      $("#employeeForm")[0].reset();
    }
  });
}

// Edit employee
function editEmployee(id) {
  $.get(`${BASE_URL}/employees/${id}`, function (emp) {
    $("#employeeId").val(emp.id);
    $("#name").val(emp.name);
    $("#email").val(emp.email);
    $("#phone").val(emp.phone);
    $("#address").val(emp.address);
    $("#designation").val(emp.designation);
    $("#organizationId").val(emp.organizationId);
  });
}

// Delete employee
function deleteEmployee(id) {
  if (confirm("Are you sure you want to delete this employee?")) {
    $.ajax({
      url: `${BASE_URL}/employees/${id}`,
      type: "DELETE",
      success: function () {
        loadEmployees();
      }
    });
  }
}
