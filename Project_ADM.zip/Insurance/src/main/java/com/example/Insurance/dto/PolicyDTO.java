// PolicyDTO.java
package com.example.Insurance.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class PolicyDTO {
    private Long id;

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(Double coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    @NotBlank(message = "Policy name is required")
    private String policyName;

    @NotNull(message = "Coverage amount is required")
    private Double coverageAmount;

    // Getters & Setters
}
