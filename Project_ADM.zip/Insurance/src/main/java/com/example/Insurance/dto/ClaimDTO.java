// ClaimDTO.java
package com.example.Insurance.dto;

import jakarta.validation.constraints.NotNull;

public class ClaimDTO {
    private Long id;

    @NotNull(message = "Claim amount is required")
    private Double claimAmount;

    private String claimReason;

    @NotNull(message = "Policy ID is required")
    private Long policyId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getClaimAmount() {
        return claimAmount;
    }

    public void setClaimAmount(Double claimAmount) {
        this.claimAmount = claimAmount;
    }

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public String getClaimReason() {
        return claimReason;
    }

    public void setClaimReason(String claimReason) {
        this.claimReason = claimReason;
    }
// Getters & Setters
}
