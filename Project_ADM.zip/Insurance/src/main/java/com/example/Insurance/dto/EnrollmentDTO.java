// EnrollmentDTO.java
package com.example.Insurance.dto;

import jakarta.validation.constraints.NotNull;

public class EnrollmentDTO {
    private Long id;

    @NotNull(message = "Employee ID is required")
    private Long employeeId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public Long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }

    @NotNull(message = "Policy ID is required")
    private Long policyId;

    // Getters & Setters
}
