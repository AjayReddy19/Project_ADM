package org.example.insurance.controller;

import org.example.insurance.model.Policy;
import org.example.insurance.service.PolicyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/policies")
public class PolicyController {

    @Autowired
    private PolicyService policyService;

    @GetMapping
    public List<Policy> getAllPolicies() {
        return policyService.getAllPolicies();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Policy> getPolicyById(@PathVariable Integer id) {
        return policyService.getPolicyById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Policy createPolicy(@RequestBody Policy policy) {
        return policyService.savePolicy(policy);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Policy> updatePolicy(@PathVariable Integer id, @RequestBody Policy policyDetails) {
        return policyService.getPolicyById(id)
                .map(policy -> {
                    policy.setPolicyName(policyDetails.getPolicyName());
                    policy.setCoverageAmount(policyDetails.getCoverageAmount());
                    policy.setPremiumAmount(policyDetails.getPremiumAmount());
                    policy.setPolicyType(policyDetails.getPolicyType());
                    Policy updated = policyService.updatePolicy(policy);
                    return ResponseEntity.ok(updated);
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePolicy(@PathVariable Integer id) {
        policyService.deletePolicy(id);
        return ResponseEntity.noContent().build();
    }
}
