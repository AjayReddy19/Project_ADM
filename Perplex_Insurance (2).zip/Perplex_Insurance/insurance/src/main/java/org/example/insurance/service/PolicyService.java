package org.example.insurance.service;

import org.example.insurance.model.Policy;

import java.util.List;
import java.util.Optional;

public interface PolicyService {
    List<Policy> getAllPolicies();
    Optional<Policy> getPolicyById(Integer id);
    Policy savePolicy(Policy policy);
    Policy updatePolicy(Policy policy);
    void deletePolicy(Integer id);
}
