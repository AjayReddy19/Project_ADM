package org.example.insurance.service;

import org.example.insurance.model.Enrollment;
import org.example.insurance.repository.EnrollmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EnrollmentServiceImpl implements EnrollmentService {

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Override
    public Enrollment enrollPolicy(Enrollment enrollment) {
        return enrollmentRepository.save(enrollment);
    }

    @Override
    public List<Enrollment> getEnrollmentsByEmployeeId(Integer employeeId) {
        return enrollmentRepository.findByEmployeeEmployeeId(employeeId);
    }

    @Override
    public Optional<Enrollment> getEnrollmentById(Integer enrollmentId) {
        return enrollmentRepository.findById(enrollmentId);
    }

    @Override
    public void cancelEnrollment(Integer enrollmentId) {
        enrollmentRepository.findById(enrollmentId).ifPresent(enrollment -> {
            enrollment.setStatus(Enrollment.EnrollmentStatus.CANCELLED);
            enrollmentRepository.save(enrollment);
        });
    }
}
