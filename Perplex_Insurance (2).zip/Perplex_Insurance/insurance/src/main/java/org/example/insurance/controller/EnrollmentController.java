package org.example.insurance.controller;

import org.example.insurance.model.Enrollment;
import org.example.insurance.service.EnrollmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/enrollments")
public class EnrollmentController {

    @Autowired
    private EnrollmentService enrollmentService;

    @PostMapping
    public Enrollment enrollPolicy(@RequestBody Enrollment enrollment) {
        enrollment.setEnrollmentDate(LocalDate.now());
        enrollment.setStatus(Enrollment.EnrollmentStatus.ACTIVE);
        return enrollmentService.enrollPolicy(enrollment);
    }

    @GetMapping("/employee/{employeeId}")
    public List<Enrollment> getEnrollmentsByEmployee(@PathVariable Integer employeeId) {
        return enrollmentService.getEnrollmentsByEmployeeId(employeeId);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Enrollment> getEnrollmentById(@PathVariable Integer id) {
        return enrollmentService.getEnrollmentById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<Void> cancelEnrollment(@PathVariable Integer id) {
        enrollmentService.cancelEnrollment(id);
        return ResponseEntity.noContent().build();
    }
}
