package org.example.insurance.controller;

import org.example.insurance.model.Employee;
import org.example.insurance.model.Enrollment;
import org.example.insurance.model.Claim;
import org.example.insurance.service.EmployeeService;
import org.example.insurance.service.EnrollmentService;
import org.example.insurance.service.ClaimService;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Controller
public class DashboardController {

    private final EmployeeService employeeService;
    private final EnrollmentService enrollmentService;
    private final ClaimService claimService;

    public DashboardController(EmployeeService employeeService,
                               EnrollmentService enrollmentService,
                               ClaimService claimService) {
        this.employeeService = employeeService;
        this.enrollmentService = enrollmentService;
        this.claimService = claimService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Authentication authentication, Model model) {
        if (authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_ADMIN"))) {
            return "admin-dashboard";

        } else if (authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_HR"))) {
            return "hr-dashboard";

        } else if (authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_EMPLOYEE"))) {
            // Get logged-in username (usually email or username)
            String username = authentication.getName();

            // Fetch employee by email
            Optional<Employee> optionalEmployee = employeeService.getEmployeeByEmail(username);

            if (optionalEmployee.isPresent()) {
                Employee employee = optionalEmployee.get();
                model.addAttribute("employee", employee);

                List<Enrollment> enrollments = enrollmentService.getEnrollmentsByEmployeeId(employee.getEmployeeId());
                model.addAttribute("enrollments", enrollments != null ? enrollments : Collections.emptyList());

                List<Claim> claims = claimService.getClaimsByEmployeeId(employee.getEmployeeId());
                model.addAttribute("claims", claims != null ? claims : Collections.emptyList());
            } else {
                // Fallback to prevent Thymeleaf null pointer
                model.addAttribute("employee", new Employee());
                model.addAttribute("enrollments", Collections.emptyList());
                model.addAttribute("claims", Collections.emptyList());
            }

            return "employee-dashboard";

        } else {
            return "access-denied";
        }
    }
}
