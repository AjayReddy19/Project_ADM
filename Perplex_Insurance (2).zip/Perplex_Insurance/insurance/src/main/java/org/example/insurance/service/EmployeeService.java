package org.example.insurance.service;

import org.example.insurance.model.Employee;

import java.util.List;
import java.util.Optional;

public interface EmployeeService {
    Employee saveEmployee(Employee employee);

    List<Employee> getAllEmployees();
    Employee save(Employee employee);
    Optional<Employee> getEmployeeById(Integer id);

    Employee updateEmployee(Employee employee);

    void deleteEmployee(Integer id);
    // In EmployeeService.java
    Optional<Employee> getEmployeeByEmail(String email);





}
