package org.example.insurance.service;

import org.example.insurance.model.Enrollment;

import java.util.List;
import java.util.Optional;

public interface EnrollmentService {
    Enrollment enrollPolicy(Enrollment enrollment);
    List<Enrollment> getEnrollmentsByEmployeeId(Integer employeeId);
    Optional<Enrollment> getEnrollmentById(Integer enrollmentId);
    void cancelEnrollment(Integer enrollmentId);
//    // In EnrollmentService.java
//    List<Enrollment> getEnrollmentsByEmployeeId(Integer employeeId);
}
