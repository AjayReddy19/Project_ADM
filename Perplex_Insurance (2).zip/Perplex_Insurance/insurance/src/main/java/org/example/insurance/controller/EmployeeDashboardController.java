package org.example.insurance.controller;

import org.example.insurance.model.Employee;
import org.example.insurance.model.Enrollment;
import org.example.insurance.model.Claim;
import org.example.insurance.service.EmployeeService;
import org.example.insurance.service.EnrollmentService;
import org.example.insurance.service.ClaimService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import java.util.Optional;

@Controller
public class EmployeeDashboardController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private EnrollmentService enrollmentService;

    @Autowired
    private ClaimService claimService;

    @GetMapping("/employee/dashboard")
    public String dashboard(Authentication authentication, Model model) {
        String email = null;
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            email = userDetails.getUsername();
            System.out.println("Logged in user email: " + email);
        }

        if (email == null) {
            model.addAttribute("message", "User information unavailable. Please login.");
            return "employee-not-found";
        }

        Optional<Employee> employeeOpt = employeeService.getEmployeeByEmail(email);

        if (employeeOpt.isEmpty()) {
            System.out.println("Employee NOT found for email: " + email);
            model.addAttribute("message", "Employee record not found. Please contact administrator.");
            return "employee-not-found";
        }

        Employee employee = employeeOpt.get();
        System.out.println("Employee found: " + employee.getName());
        model.addAttribute("employee", employee);

        List<Enrollment> enrollments = enrollmentService.getEnrollmentsByEmployeeId(employee.getEmployeeId());
        model.addAttribute("enrollments", enrollments);

        List<Claim> claims = claimService.getClaimsByEmployeeId(employee.getEmployeeId());
        model.addAttribute("claims", claims);

        return "employee-dashboard";
    }
}
