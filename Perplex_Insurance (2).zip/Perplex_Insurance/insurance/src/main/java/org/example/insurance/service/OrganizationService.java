package org.example.insurance.service;

import org.example.insurance.model.Organization;

import java.util.List;
import java.util.Optional;

public interface OrganizationService {
    List<Organization> getAllOrganizations();
    Optional<Organization> getOrganizationById(Long id);
    Organization saveOrganization(Organization organization);
    Organization updateOrganization(Organization organization);
    void deleteOrganization(Long id);
}
