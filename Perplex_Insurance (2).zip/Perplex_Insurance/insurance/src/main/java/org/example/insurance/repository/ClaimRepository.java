package org.example.insurance.repository;

import org.example.insurance.model.Claim;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClaimRepository extends JpaRepository<Claim, Integer> {

    @Query("SELECT c FROM Claim c WHERE c.enrollment.employee.employeeId = :employeeId")
    List<Claim> findByEmployeeId(@Param("employeeId") Integer employeeId);

    @Query("SELECT c FROM Claim c WHERE c.enrollment.enrollmentId = :enrollmentId")
    List<Claim> findByEnrollmentId(@Param("enrollmentId") Integer enrollmentId);

}
