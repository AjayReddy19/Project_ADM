package org.example.insurance.service;

import org.example.insurance.model.Claim;

import java.util.List;
import java.util.Optional;

public interface ClaimService {
    Claim fileClaim(Claim claim);
    List<Claim> getClaimsByEnrollmentId(Integer enrollmentId);
    Optional<Claim> getClaimById(Integer claimId);
    Claim updateClaimStatus(Integer claimId, String status);
    List<Claim> getClaimsByEmployeeId(Integer employeeId);
}
