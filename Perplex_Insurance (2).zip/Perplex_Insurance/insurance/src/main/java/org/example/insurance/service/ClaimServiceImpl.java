package org.example.insurance.service;

import org.example.insurance.model.Claim;
import org.example.insurance.repository.ClaimRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClaimServiceImpl implements ClaimService {

    @Autowired
    private ClaimRepository claimRepository;

    @Override
    public Claim fileClaim(Claim claim) {
        return claimRepository.save(claim);
    }

    @Override
    public List<Claim> getClaimsByEnrollmentId(Integer enrollmentId) {
        return claimRepository.findByEnrollmentId(enrollmentId);
    }

    @Override
    public Optional<Claim> getClaimById(Integer claimId) {
        return claimRepository.findById(claimId);
    }

    @Override
    public Claim updateClaimStatus(Integer claimId, String status) {
        Optional<Claim> claimOpt = claimRepository.findById(claimId);
        if (claimOpt.isPresent()) {
            Claim claim = claimOpt.get();
            claim.setStatus(status);
            return claimRepository.save(claim);
        }
        return null;
    }

    @Override
    public List<Claim> getClaimsByEmployeeId(Integer employeeId) {
        return claimRepository.findByEmployeeId(employeeId);
    }
}
