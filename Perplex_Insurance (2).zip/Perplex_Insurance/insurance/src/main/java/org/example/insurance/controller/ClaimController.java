package org.example.insurance.controller;

import org.example.insurance.model.Claim;
import org.example.insurance.service.ClaimService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/claims")
public class ClaimController {

    @Autowired
    private ClaimService claimService;

    @PostMapping
    public Claim fileClaim(@RequestBody Claim claim) {
        return claimService.fileClaim(claim);
    }

    @GetMapping("/enrollment/{enrollmentId}")
    public List<Claim> getClaimsByEnrollment(@PathVariable Integer enrollmentId) {
        return claimService.getClaimsByEnrollmentId(enrollmentId);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Claim> getClaimById(@PathVariable Integer id) {
        return claimService.getClaimById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Claim> updateClaimStatus(@PathVariable Integer id, @RequestParam String status) {
        Claim claim = claimService.updateClaimStatus(id, status);
        if (claim != null) {
            return ResponseEntity.ok(claim);
        }
        return ResponseEntity.notFound().build();
    }
}
