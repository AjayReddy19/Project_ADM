package org.example.insurance.config;

import org.example.insurance.model.User;
import org.example.insurance.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Set;

@Configuration
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        if (userRepository.findByEmail("admin123@gmail.com").isEmpty()) {
            User admin = new User();
            admin.setEmail("admin123@gmail.com");
            admin.setPassword(passwordEncoder.encode("admin"));
            admin.setRoles(Set.of("ADMIN"));
            userRepository.save(admin);
            System.out.println("Admin user created");
        }
    }
}
