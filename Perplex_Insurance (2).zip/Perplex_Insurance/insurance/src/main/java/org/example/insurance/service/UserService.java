package org.example.insurance.service;

import org.example.insurance.model.User;

public interface UserService {
    boolean existsByEmail(String email);
    User save(User user);
}
